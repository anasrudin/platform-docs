package steps

import (
	"context"
	"fmt"
	"time"

	"platform-core/internal/orchestration/code_controller"
	"platform-core/internal/telemetry"
)

// CreateRuntime allocates a warm Sandbox from a SandboxWarmPool via a SandboxClaim.
type CreateRuntime struct {
	sc           *code_controller.SandboxClient
	templateName string
	runtimeClass string
}

func NewCreateRuntime(sc *code_controller.SandboxClient, templateName, runtimeClass string) *CreateRuntime {
	return &CreateRuntime{sc: sc, templateName: templateName, runtimeClass: runtimeClass}
}

func (s *CreateRuntime) Run(ctx context.Context, pCtx *PipelineContext) error {
	ctx, span := telemetry.Start(ctx, "step.create_runtime")
	defer span.End()

	jobID := pCtx.Job.JobID

	// Create a SandboxClaim — agent-sandbox will allocate a warm pod.
	claim, err := s.sc.CreateClaim(ctx, jobID, s.templateName, map[string]string{
		"platform.io/tool": pCtx.Job.ToolName,
		"platform.io/tier": pCtx.Job.Tier,
	})
	if err != nil {
		return fmt.Errorf("create claim: %w", err)
	}

	pCtx.ClaimName = claim.Name

	// Wait up to 30s for the sandbox to be allocated and ready.
	sandbox, err := s.sc.WaitForClaim(ctx, claim.Name, 30*time.Second)
	if err != nil {
		return fmt.Errorf("wait for sandbox: %w", err)
	}

	pCtx.SandboxName = sandbox.Name
	pCtx.GRPCAddr = s.sc.GetSandboxGRPCAddr(sandbox.Name)
	return nil
}
