package steps

import (
	"context"
	"encoding/json"
	"fmt"
	"net/url"
	"time"

	"github.com/minio/minio-go/v7"
	"github.com/minio/minio-go/v7/pkg/credentials"
	corev1 "k8s.io/api/core/v1"

	"platform-core/internal/telemetry"
)

// DownloadArtifact resolves input artifact IDs to presigned MinIO URLs
// and injects them as env vars into the pipeline context.
type DownloadArtifact struct {
	endpoint string
	bucket   string
	key      string
	secret   string
	useSSL   bool
}

func NewDownloadArtifact(endpoint, bucket, key, secret string, useSSL bool) *DownloadArtifact {
	return &DownloadArtifact{endpoint: endpoint, bucket: bucket, key: key, secret: secret, useSSL: useSSL}
}

func (s *DownloadArtifact) Run(ctx context.Context, pCtx *PipelineContext) error {
	ctx, span := telemetry.Start(ctx, "step.download_artifact")
	defer span.End()

	// Parse artifact IDs from job input.
	var input map[string]json.RawMessage
	if err := json.Unmarshal([]byte(pCtx.Job.InputJSON), &input); err != nil {
		return nil // No artifacts required — not an error.
	}

	rawArtifacts, ok := input["artifacts"]
	if !ok {
		return nil // No artifacts field.
	}

	var artifactIDs []string
	if err := json.Unmarshal(rawArtifacts, &artifactIDs); err != nil {
		return fmt.Errorf("parse artifact ids: %w", err)
	}
	if len(artifactIDs) == 0 {
		return nil
	}

	mc, err := minio.New(s.endpoint, &minio.Options{
		Creds:  credentials.NewStaticV4(s.key, s.secret, ""),
		Secure: s.useSSL,
	})
	if err != nil {
		return fmt.Errorf("minio client: %w", err)
	}

	for i, id := range artifactIDs {
		objectKey := fmt.Sprintf("artifacts/%s", id)
		presignedURL, err := mc.PresignedGetObject(ctx, s.bucket, objectKey, 5*time.Minute, url.Values{})
		if err != nil {
			return fmt.Errorf("presign artifact %s: %w", id, err)
		}
		pCtx.EnvVars = append(pCtx.EnvVars, corev1.EnvVar{
			Name:  fmt.Sprintf("ARTIFACT_%d_URL", i),
			Value: presignedURL.String(),
		})
	}
	return nil
}
