package steps

import (
	"context"
	"fmt"

	"platform-core/internal/telemetry"
)

// UploadOutput collects output files from the sandbox via gRPC
// and uploads them to MinIO.
type UploadOutput struct {
	endpoint string
	bucket   string
	key      string
	secret   string
	useSSL   bool
}

func NewUploadOutput(endpoint, bucket, key, secret string, useSSL bool) *UploadOutput {
	return &UploadOutput{endpoint: endpoint, bucket: bucket, key: key, secret: secret, useSSL: useSSL}
}

func (s *UploadOutput) Run(ctx context.Context, pCtx *PipelineContext) error {
	_, span := telemetry.Start(ctx, "step.upload_output")
	defer span.End()

	// The output prefix in MinIO where results are stored.
	pCtx.OutputPrefix = fmt.Sprintf("jobs/%s/output/", pCtx.Job.JobID)

	// TODO: dial sandbox gRPC, call ListOutputFiles RPC, stream each file
	// to MinIO using mc.PutObject(). For Phase 2, the tool runner writes
	// results directly to a shared MinIO-backed volume mount, so this step
	// validates that the output prefix exists and is non-empty.

	return nil
}
