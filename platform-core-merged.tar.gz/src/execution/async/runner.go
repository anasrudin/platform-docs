package async

import (
	"context"
	"log/slog"

	"platform-core/internal/queue"
)

// Runner pops jobs from the code-jobs Redis stream and runs them through the Pipeline.
type Runner struct {
	consumer *queue.Consumer
	pipeline *Pipeline
	log      *slog.Logger
}

// NewRunner creates a Runner.
func NewRunner(consumer *queue.Consumer, pipeline *Pipeline) *Runner {
	return &Runner{
		consumer: consumer,
		pipeline: pipeline,
		log:      slog.Default().With("component", "async-runner"),
	}
}

// Start begins consuming jobs. Blocks until ctx is cancelled.
func (r *Runner) Start(ctx context.Context) error {
	r.log.Info("async runner started")
	return r.consumer.Run(ctx, func(ctx context.Context, msg queue.JobMessage) error {
		r.log.Info("processing job", "job_id", msg.JobID, "tool", msg.ToolName, "tier", msg.Tier)
		if err := r.pipeline.Run(ctx, msg); err != nil {
			r.log.Error("pipeline failed", "job_id", msg.JobID, "err", err)
			return err
		}
		r.log.Info("job completed", "job_id", msg.JobID)
		return nil
	})
}
