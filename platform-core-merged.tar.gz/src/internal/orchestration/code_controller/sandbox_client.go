package code_controller

import (
	"context"
	"fmt"
	"time"

	corev1 "k8s.io/api/core/v1"
	"k8s.io/apimachinery/pkg/api/resource"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/types"
	"k8s.io/apimachinery/pkg/util/wait"
	"sigs.k8s.io/controller-runtime/pkg/client"

	// agent-sandbox core API
	sandboxv1 "sigs.k8s.io/agent-sandbox/api/v1alpha1"
	// agent-sandbox extensions API (SandboxTemplate, SandboxClaim, SandboxWarmPool)
	extv1 "sigs.k8s.io/agent-sandbox/extensions/api/v1alpha1"
)

// ResourceLimits describes the resource envelope applied to a sandbox.
type ResourceLimits struct {
	CPU              string // e.g. "2"
	Memory           string // e.g. "2Gi"
	EphemeralStorage string // e.g. "10Gi"
}

// SandboxClient manages agent-sandbox CRDs for code execution jobs.
type SandboxClient struct {
	k8s       client.Client
	namespace string
}

// NewSandboxClient creates a SandboxClient using the given controller-runtime client.
func NewSandboxClient(k8s client.Client, namespace string) *SandboxClient {
	return &SandboxClient{k8s: k8s, namespace: namespace}
}

// ─────────────────────────────────────────────────────────
// SandboxTemplate management
// ─────────────────────────────────────────────────────────

// EnsureTemplate creates or updates a SandboxTemplate for the given runtime tier.
// Called once at startup for each configured tier.
func (sc *SandboxClient) EnsureTemplate(ctx context.Context, name, image, runtimeClass string, limits ResourceLimits) error {
	tmpl := &extv1.SandboxTemplate{
		ObjectMeta: metav1.ObjectMeta{
			Name:      name,
			Namespace: sc.namespace,
		},
		Spec: extv1.SandboxTemplateSpec{
			PodTemplate: corev1.PodTemplateSpec{
				Spec: corev1.PodSpec{
					RuntimeClassName: &runtimeClass,
					Containers: []corev1.Container{
						{
							Name:  "tool-runner",
							Image: image,
							Ports: []corev1.ContainerPort{
								{Name: "grpc", ContainerPort: 50051, Protocol: corev1.ProtocolTCP},
							},
							ReadinessProbe: &corev1.Probe{
								ProbeHandler: corev1.ProbeHandler{
									GRPC: &corev1.GRPCAction{Port: 50051},
								},
								InitialDelaySeconds: 2,
								PeriodSeconds:       3,
							},
							Resources: corev1.ResourceRequirements{
								Requests: corev1.ResourceList{
									corev1.ResourceCPU:              resource.MustParse(limits.CPU),
									corev1.ResourceMemory:           resource.MustParse(limits.Memory),
									corev1.ResourceEphemeralStorage: resource.MustParse(limits.EphemeralStorage),
								},
								Limits: corev1.ResourceList{
									corev1.ResourceCPU:              resource.MustParse(limits.CPU),
									corev1.ResourceMemory:           resource.MustParse(limits.Memory),
									corev1.ResourceEphemeralStorage: resource.MustParse(limits.EphemeralStorage),
								},
							},
						},
					},
				},
			},
		},
	}

	existing := &extv1.SandboxTemplate{}
	err := sc.k8s.Get(ctx, types.NamespacedName{Name: name, Namespace: sc.namespace}, existing)
	if err != nil {
		// Create
		return sc.k8s.Create(ctx, tmpl)
	}
	// Update spec
	existing.Spec = tmpl.Spec
	return sc.k8s.Update(ctx, existing)
}

// ─────────────────────────────────────────────────────────
// SandboxWarmPool management
// ─────────────────────────────────────────────────────────

// EnsureWarmPool creates or updates a SandboxWarmPool for a given template.
func (sc *SandboxClient) EnsureWarmPool(ctx context.Context, poolName, templateName string, replicas int32) error {
	pool := &extv1.SandboxWarmPool{
		ObjectMeta: metav1.ObjectMeta{
			Name:      poolName,
			Namespace: sc.namespace,
		},
		Spec: extv1.SandboxWarmPoolSpec{
			Replicas: replicas,
			SandboxTemplateRef: corev1.LocalObjectReference{
				Name: templateName,
			},
		},
	}

	existing := &extv1.SandboxWarmPool{}
	err := sc.k8s.Get(ctx, types.NamespacedName{Name: poolName, Namespace: sc.namespace}, existing)
	if err != nil {
		return sc.k8s.Create(ctx, pool)
	}
	existing.Spec.Replicas = replicas
	return sc.k8s.Update(ctx, existing)
}

// ─────────────────────────────────────────────────────────
// SandboxClaim — allocate a warm sandbox for a job
// ─────────────────────────────────────────────────────────

// CreateClaim creates a SandboxClaim that allocates one sandbox from a WarmPool.
// The claim name is deterministic: "job-<jobID>".
func (sc *SandboxClient) CreateClaim(ctx context.Context, jobID, templateName string, extraLabels map[string]string) (*extv1.SandboxClaim, error) {
	claimName := "job-" + jobID

	labels := map[string]string{
		"platform.io/job-id": jobID,
	}
	for k, v := range extraLabels {
		labels[k] = v
	}

	claim := &extv1.SandboxClaim{
		ObjectMeta: metav1.ObjectMeta{
			Name:      claimName,
			Namespace: sc.namespace,
			Labels:    labels,
		},
		Spec: extv1.SandboxClaimSpec{
			SandboxTemplateName: templateName,
		},
	}

	if err := sc.k8s.Create(ctx, claim); err != nil {
		return nil, fmt.Errorf("create sandbox claim: %w", err)
	}
	return claim, nil
}

// WaitForClaim polls the SandboxClaim until its bound Sandbox is Ready,
// then returns the Sandbox object.
func (sc *SandboxClient) WaitForClaim(ctx context.Context, claimName string, timeout time.Duration) (*sandboxv1.Sandbox, error) {
	deadline := time.Now().Add(timeout)
	var sandboxName string

	// Phase 1: wait for claim to be bound (SandboxClaim.Status.SandboxName != "")
	err := wait.PollUntilContextTimeout(ctx, 500*time.Millisecond, timeout, true, func(ctx context.Context) (bool, error) {
		claim := &extv1.SandboxClaim{}
		if err := sc.k8s.Get(ctx, types.NamespacedName{Name: claimName, Namespace: sc.namespace}, claim); err != nil {
			return false, nil
		}
		if claim.Status.SandboxName != "" {
			sandboxName = claim.Status.SandboxName
			return true, nil
		}
		return false, nil
	})
	if err != nil {
		return nil, fmt.Errorf("waiting for claim %s to bind: %w", claimName, err)
	}

	// Phase 2: wait for the Sandbox to be Ready.
	remaining := time.Until(deadline)
	if remaining <= 0 {
		remaining = 5 * time.Second
	}

	var sandbox *sandboxv1.Sandbox
	err = wait.PollUntilContextTimeout(ctx, 500*time.Millisecond, remaining, true, func(ctx context.Context) (bool, error) {
		sb := &sandboxv1.Sandbox{}
		if err := sc.k8s.Get(ctx, types.NamespacedName{Name: sandboxName, Namespace: sc.namespace}, sb); err != nil {
			return false, nil
		}
		for _, cond := range sb.Status.Conditions {
			if cond.Type == string(sandboxv1.SandboxConditionReady) && cond.Status == metav1.ConditionTrue {
				sandbox = sb
				return true, nil
			}
		}
		return false, nil
	})
	if err != nil {
		return nil, fmt.Errorf("sandbox %s never became ready: %w", sandboxName, err)
	}
	return sandbox, nil
}

// DeleteClaim removes a SandboxClaim (and the owned Sandbox via GC).
func (sc *SandboxClient) DeleteClaim(ctx context.Context, jobID string) error {
	claim := &extv1.SandboxClaim{
		ObjectMeta: metav1.ObjectMeta{
			Name:      "job-" + jobID,
			Namespace: sc.namespace,
		},
	}
	return client.IgnoreNotFound(sc.k8s.Delete(ctx, claim))
}

// ─────────────────────────────────────────────────────────
// Direct Sandbox creation (no warm pool — for desktop tier)
// ─────────────────────────────────────────────────────────

// CreateSandbox creates a Sandbox CRD directly (used by desktop controller).
func (sc *SandboxClient) CreateSandbox(ctx context.Context, name, image, runtimeClass string, limits ResourceLimits, envVars []corev1.EnvVar) (*sandboxv1.Sandbox, error) {
	sb := &sandboxv1.Sandbox{
		ObjectMeta: metav1.ObjectMeta{
			Name:      name,
			Namespace: sc.namespace,
		},
		Spec: sandboxv1.SandboxSpec{
			PodTemplate: corev1.PodTemplateSpec{
				Spec: corev1.PodSpec{
					RuntimeClassName: &runtimeClass,
					Containers: []corev1.Container{
						{
							Name:  "runner",
							Image: image,
							Env:   envVars,
							Resources: corev1.ResourceRequirements{
								Limits: corev1.ResourceList{
									corev1.ResourceCPU:              resource.MustParse(limits.CPU),
									corev1.ResourceMemory:           resource.MustParse(limits.Memory),
									corev1.ResourceEphemeralStorage: resource.MustParse(limits.EphemeralStorage),
								},
							},
						},
					},
				},
			},
		},
	}

	if err := sc.k8s.Create(ctx, sb); err != nil {
		return nil, err
	}
	return sb, nil
}

// PauseSandbox scales a Sandbox to 0 replicas (hibernation).
func (sc *SandboxClient) PauseSandbox(ctx context.Context, sandboxName string) error {
	return sc.patchReplicas(ctx, sandboxName, 0)
}

// ResumeSandbox scales a Sandbox to 1 replica.
func (sc *SandboxClient) ResumeSandbox(ctx context.Context, sandboxName string) error {
	return sc.patchReplicas(ctx, sandboxName, 1)
}

// DeleteSandbox deletes a Sandbox CRD.
func (sc *SandboxClient) DeleteSandbox(ctx context.Context, sandboxName string) error {
	sb := &sandboxv1.Sandbox{
		ObjectMeta: metav1.ObjectMeta{Name: sandboxName, Namespace: sc.namespace},
	}
	return client.IgnoreNotFound(sc.k8s.Delete(ctx, sb))
}

func (sc *SandboxClient) patchReplicas(ctx context.Context, sandboxName string, replicas int32) error {
	sb := &sandboxv1.Sandbox{}
	if err := sc.k8s.Get(ctx, types.NamespacedName{Name: sandboxName, Namespace: sc.namespace}, sb); err != nil {
		return err
	}
	sb.Spec.Replicas = &replicas
	return sc.k8s.Update(ctx, sb)
}

// GetSandboxGRPCAddr returns the in-cluster gRPC address for a Sandbox.
// agent-sandbox creates a headless service: <sandbox-name>.<namespace>.svc.cluster.local
func (sc *SandboxClient) GetSandboxGRPCAddr(sandboxName string) string {
	return fmt.Sprintf("%s.%s.svc.cluster.local:50051", sandboxName, sc.namespace)
}
