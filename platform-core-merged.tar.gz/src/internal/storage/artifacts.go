package storage

import (
	"context"
	"time"
)

// Artifact represents an input or output file for a job.
type Artifact struct {
	ArtifactID string    `json:"artifact_id" db:"artifact_id"`
	JobID      string    `json:"job_id"      db:"job_id"`
	Filename   string    `json:"filename"    db:"filename"`
	MinIOKey   string    `json:"minio_key"   db:"minio_key"`
	SizeBytes  int64     `json:"size_bytes"  db:"size_bytes"`
	Checksum   string    `json:"checksum"    db:"checksum"`
	Direction  string    `json:"direction"   db:"direction"` // input | output
	CreatedAt  time.Time `json:"created_at"  db:"created_at"`
}

// ArtifactStore handles artifact persistence.
type ArtifactStore struct{ db *DB }

// NewArtifactStore creates an ArtifactStore.
func NewArtifactStore(db *DB) *ArtifactStore { return &ArtifactStore{db: db} }

// Create inserts a new artifact record.
func (s *ArtifactStore) Create(ctx context.Context, a *Artifact) error {
	_, err := s.db.Pool.Exec(ctx, `
		INSERT INTO artifacts (job_id, filename, minio_key, size_bytes, checksum)
		VALUES ($1,$2,$3,$4,$5)`,
		a.JobID, a.Filename, a.MinIOKey, a.SizeBytes, a.Checksum,
	)
	return err
}

// ListByJob returns all artifacts for a job.
func (s *ArtifactStore) ListByJob(ctx context.Context, jobID string) ([]*Artifact, error) {
	rows, err := s.db.Pool.Query(ctx, `
		SELECT artifact_id::text, job_id::text, filename, minio_key,
		       COALESCE(size_bytes,0), COALESCE(checksum,''), created_at
		FROM artifacts WHERE job_id=$1 ORDER BY created_at`,
		jobID,
	)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var arts []*Artifact
	for rows.Next() {
		a := &Artifact{}
		if err := rows.Scan(&a.ArtifactID, &a.JobID, &a.Filename, &a.MinIOKey,
			&a.SizeBytes, &a.Checksum, &a.CreatedAt); err != nil {
			return nil, err
		}
		arts = append(arts, a)
	}
	return arts, nil
}
