-- 002_sessions.sql
CREATE TABLE IF NOT EXISTS desktop_sessions (
    session_id      UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
    agent_id        TEXT        NOT NULL,
    job_id          UUID        REFERENCES jobs(job_id),
    sandbox_name    TEXT        NOT NULL,
    vnc_url         TEXT,
    status          TEXT        NOT NULL DEFAULT 'creating'
                                CHECK (status IN ('creating','ready','paused','hibernated','destroyed')),
    last_heartbeat  TIMESTAMPTZ,
    snapshot_ref    TEXT,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    destroyed_at    TIMESTAMPTZ
);
