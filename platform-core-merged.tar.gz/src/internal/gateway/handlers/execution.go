package handlers

import (
	"encoding/json"
	"net/http"

	"github.com/google/uuid"

	"platform-core/internal/queue"
	"platform-core/internal/storage"
)

// ExecuteRequest is the JSON body for POST /v1/execute.
type ExecuteRequest struct {
	Tool        string          `json:"tool"`
	Tier        string          `json:"tier"` // wasm | headless | gui
	Input       json.RawMessage `json:"input"`
	CallbackURL string          `json:"callback_url,omitempty"`
}

// ExecuteResponse is returned for async jobs (HTTP 202).
type ExecuteResponse struct {
	JobID string `json:"job_id"`
}

// ExecutionHandler handles POST /v1/execute.
type ExecutionHandler struct {
	producer *queue.Producer
	jobStore *storage.JobStore
}

// NewExecutionHandler creates an ExecutionHandler.
func NewExecutionHandler(producer *queue.Producer, jobStore *storage.JobStore) *ExecutionHandler {
	return &ExecutionHandler{producer: producer, jobStore: jobStore}
}

// ServeHTTP handles code execution requests.
func (h *ExecutionHandler) ServeHTTP(w http.ResponseWriter, r *http.Request) {
	var req ExecuteRequest
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		writeError(w, http.StatusBadRequest, "invalid request body")
		return
	}

	if req.Tool == "" {
		writeError(w, http.StatusBadRequest, "tool is required")
		return
	}
	if req.Tier == "" {
		req.Tier = "headless" // sensible default
	}

	// Extract agent_id injected by auth middleware.
	agentID, _ := r.Context().Value(contextKeyAgentID).(string)
	jobID := uuid.New().String()

	inputBytes, _ := req.Input.MarshalJSON()

	job := &storage.Job{
		JobID:       jobID,
		ToolName:    req.Tool,
		Tier:        req.Tier,
		AgentID:     agentID,
		InputJSON:   inputBytes,
		CallbackURL: req.CallbackURL,
	}

	if err := h.jobStore.Create(r.Context(), job); err != nil {
		writeError(w, http.StatusInternalServerError, "failed to create job")
		return
	}

	msg := queue.JobMessage{
		JobID:       jobID,
		ToolName:    req.Tool,
		Tier:        req.Tier,
		AgentID:     agentID,
		InputJSON:   string(inputBytes),
		CallbackURL: req.CallbackURL,
	}

	if err := h.producer.Push(r.Context(), msg); err != nil {
		writeError(w, http.StatusInternalServerError, "failed to enqueue job")
		return
	}

	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(http.StatusAccepted)
	_ = json.NewEncoder(w).Encode(ExecuteResponse{JobID: jobID})
}
