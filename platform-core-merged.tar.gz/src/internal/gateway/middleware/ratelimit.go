package middleware

import (
	"context"
	"encoding/json"
	"fmt"
	"net/http"
	"time"

	"github.com/redis/go-redis/v9"

	"platform-core/internal/gateway/handlers"
)

// RateLimits defines per-tier token bucket limits (requests per minute).
type RateLimits struct {
	WasmPerMinute    int
	AsyncPerMinute   int
	DesktopPerMinute int
}

// RateLimit returns a Redis-backed token bucket rate limiting middleware.
func RateLimit(client *redis.Client, limits RateLimits) func(http.Handler) http.Handler {
	return func(next http.Handler) http.Handler {
		return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
			agentID, _ := r.Context().Value(handlers.ContextKeyAgentID).(string)
			if agentID == "" {
				next.ServeHTTP(w, r)
				return
			}

			tier := tierFromPath(r.URL.Path)
			maxTokens := maxTokensForTier(tier, limits)
			key := fmt.Sprintf("ratelimit:%s:%s", agentID, tier)

			allowed, retryAfter, err := checkBucket(r.Context(), client, key, maxTokens)
			if err != nil {
				// On Redis error, allow the request (fail open).
				next.ServeHTTP(w, r)
				return
			}

			if !allowed {
				w.Header().Set("Retry-After", fmt.Sprintf("%d", retryAfter))
				w.Header().Set("Content-Type", "application/json")
				w.WriteHeader(http.StatusTooManyRequests)
				_ = json.NewEncoder(w).Encode(map[string]string{
					"error":       "rate limit exceeded",
					"retry_after": fmt.Sprintf("%ds", retryAfter),
				})
				return
			}

			next.ServeHTTP(w, r)
		})
	}
}

// checkBucket runs a Lua script to atomically decrement a token bucket.
// Returns (allowed bool, retryAfterSeconds int, err error).
func checkBucket(ctx context.Context, client *redis.Client, key string, maxTokens int) (bool, int, error) {
	script := redis.NewScript(`
		local key       = KEYS[1]
		local maxTokens = tonumber(ARGV[1])
		local now       = tonumber(ARGV[2])
		local period    = 60  -- 1 minute refill window

		local data = redis.call("HMGET", key, "tokens", "last_refill")
		local tokens     = tonumber(data[1]) or maxTokens
		local lastRefill = tonumber(data[2]) or now

		-- Refill tokens based on elapsed time
		local elapsed  = now - lastRefill
		local refilled = math.floor(elapsed / period * maxTokens)
		tokens = math.min(maxTokens, tokens + refilled)
		if refilled > 0 then lastRefill = now end

		if tokens < 1 then
			redis.call("HMSET", key, "tokens", tokens, "last_refill", lastRefill)
			redis.call("EXPIRE", key, period * 2)
			local retryAfter = math.ceil((1 - tokens) / maxTokens * period)
			return {0, retryAfter}
		end

		tokens = tokens - 1
		redis.call("HMSET", key, "tokens", tokens, "last_refill", lastRefill)
		redis.call("EXPIRE", key, period * 2)
		return {1, 0}
	`)

	now := time.Now().Unix()
	result, err := script.Run(ctx, client, []string{key}, maxTokens, now).Int64Slice()
	if err != nil {
		return true, 0, err
	}
	return result[0] == 1, int(result[1]), nil
}

func tierFromPath(path string) string {
	// Simple heuristic: check for tier query param or use path suffix.
	// In production, parse the request body tier field upstream.
	return "async"
}

func maxTokensForTier(tier string, limits RateLimits) int {
	switch tier {
	case "wasm":
		return limits.WasmPerMinute
	case "desktop", "gui":
		return limits.DesktopPerMinute
	default:
		return limits.AsyncPerMinute
	}
}
