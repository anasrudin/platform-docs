package queue

import (
	"context"
	"encoding/json"
	"fmt"

	"github.com/redis/go-redis/v9"
)

// JobMessage is the payload pushed onto a Redis stream.
type JobMessage struct {
	JobID       string `json:"job_id"`
	ToolName    string `json:"tool_name"`
	Tier        string `json:"tier"`
	AgentID     string `json:"agent_id"`
	InputJSON   string `json:"input_json"`
	CallbackURL string `json:"callback_url,omitempty"`
}

// Producer pushes jobs onto Redis Streams.
type Producer struct {
	client      *redis.Client
	codeStream  string
	deskStream  string
}

// NewProducer creates a Producer connected to the given Redis URL.
func NewProducer(redisURL, codeStream, desktopStream string) (*Producer, error) {
	opt, err := redis.ParseURL(redisURL)
	if err != nil {
		return nil, fmt.Errorf("parse redis url: %w", err)
	}
	return &Producer{
		client:     redis.NewClient(opt),
		codeStream: codeStream,
		deskStream: desktopStream,
	}, nil
}

// Push enqueues a job on the appropriate stream based on tier.
func (p *Producer) Push(ctx context.Context, msg JobMessage) error {
	stream := p.codeStream
	if msg.Tier == "gui" {
		stream = p.deskStream
	}

	payload, err := json.Marshal(msg)
	if err != nil {
		return fmt.Errorf("marshal job message: %w", err)
	}

	return p.client.XAdd(ctx, &redis.XAddArgs{
		Stream: stream,
		Values: map[string]interface{}{"payload": payload},
	}).Err()
}

// Close shuts down the Redis client.
func (p *Producer) Close() error { return p.client.Close() }
