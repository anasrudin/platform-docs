package main

import (
	"context"
	"log/slog"
	"os"
	"os/signal"
	"syscall"
	"time"

	"github.com/spf13/viper"

	"platform-core/internal/gateway"
	"platform-core/internal/queue"
	"platform-core/internal/storage"
	"platform-core/internal/telemetry"
)

func main() {
	// ── Config ───────────────────────────────────────────────────────────────
	viper.SetConfigName("app")
	viper.SetConfigType("yaml")
	viper.AddConfigPath("./config")
	viper.AutomaticEnv()
	if err := viper.ReadInConfig(); err != nil {
		slog.Error("load config", "err", err)
		os.Exit(1)
	}

	ctx, stop := signal.NotifyContext(context.Background(), syscall.SIGINT, syscall.SIGTERM)
	defer stop()

	// ── Telemetry ────────────────────────────────────────────────────────────
	shutdown, err := telemetry.Init(ctx,
		viper.GetString("telemetry.service_name"),
		viper.GetString("telemetry.otlp_endpoint"),
		viper.GetBool("telemetry.insecure"),
	)
	if err != nil {
		slog.Warn("telemetry init failed, continuing without traces", "err", err)
	} else {
		defer func() { _ = shutdown(context.Background()) }()
	}

	// ── Storage ──────────────────────────────────────────────────────────────
	db, err := storage.Connect(ctx, viper.GetString("storage.postgres_dsn"))
	if err != nil {
		slog.Error("postgres connect", "err", err)
		os.Exit(1)
	}
	defer db.Close()

	// Auto-run SQL migrations on startup
	if err := db.Migrate(ctx); err != nil {
		slog.Error("migrations failed", "err", err)
		os.Exit(1)
	}
	slog.Info("migrations ok")

	jobStore := storage.NewJobStore(db)

	// ── Queue (Redis) ─────────────────────────────────────────────────────────
	producer, err := queue.NewProducer(
		viper.GetString("queue.redis_url"),
		viper.GetString("queue.code_stream"),
		viper.GetString("queue.desktop_stream"),
	)
	if err != nil {
		slog.Error("redis producer init", "err", err)
		os.Exit(1)
	}
	defer func() { _ = producer.Close() }()

	// ── JWT public key ───────────────────────────────────────────────────────
	// In dev mode (key file missing), JWT validation is skipped.
	jwtPubKey, err := os.ReadFile(viper.GetString("vault.jwt_public_key_path"))
	if err != nil {
		slog.Warn("JWT public key not found — running in DEV MODE (no auth)", "err", err)
		jwtPubKey = devPublicKeyPEM()
	}

	// ── Router & Server ──────────────────────────────────────────────────────
	router := gateway.NewRouter(producer, jobStore, jwtPubKey)
	srv := gateway.NewServer(
		viper.GetInt("gateway.port"),
		router,
		time.Duration(viper.GetInt("gateway.shutdown_timeout_seconds"))*time.Second,
	)

	slog.Info("gateway starting", "port", viper.GetInt("gateway.port"))

	go func() {
		if err := srv.Start(); err != nil {
			slog.Error("gateway stopped", "err", err)
		}
	}()

	<-ctx.Done()
	slog.Info("shutting down gateway")

	shutCtx, cancel := context.WithTimeout(context.Background(), 30*time.Second)
	defer cancel()
	_ = srv.Shutdown(shutCtx)
}

// devPublicKeyPEM returns a self-signed RSA public key PEM for local development.
// NEVER use this in production.
func devPublicKeyPEM() []byte {
	// In dev mode skip JWT validation entirely by returning nil.
	// The auth middleware checks for nil and allows all requests.
	return nil
}
