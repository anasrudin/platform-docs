package main

import (
	"context"
	"log/slog"
	"os"
	"os/signal"
	"syscall"

	"github.com/spf13/viper"
	"k8s.io/apimachinery/pkg/runtime"
	utilruntime "k8s.io/apimachinery/pkg/util/runtime"
	clientgoscheme "k8s.io/client-go/kubernetes/scheme"
	ctrl "sigs.k8s.io/controller-runtime"
	"sigs.k8s.io/controller-runtime/pkg/client"

	// agent-sandbox core CRDs
	sandboxv1 "sigs.k8s.io/agent-sandbox/api/v1alpha1"
	// agent-sandbox extensions CRDs
	extv1 "sigs.k8s.io/agent-sandbox/extensions/api/v1alpha1"

	"platform-core/execution/async"
	"platform-core/internal/orchestration/code_controller"
	"platform-core/internal/queue"
	"platform-core/internal/storage"
	"platform-core/internal/telemetry"
)

func main() {
	// ── Config ───────────────────────────────────────────────────────────────
	viper.SetConfigName("app")
	viper.SetConfigType("yaml")
	viper.AddConfigPath("./config")
	viper.AutomaticEnv()
	if err := viper.ReadInConfig(); err != nil {
		slog.Error("load config", "err", err)
		os.Exit(1)
	}

	ctx, stop := signal.NotifyContext(context.Background(), syscall.SIGINT, syscall.SIGTERM)
	defer stop()

	// ── Telemetry ────────────────────────────────────────────────────────────
	shutdown, err := telemetry.Init(ctx,
		viper.GetString("telemetry.service_name")+"-orchestrator",
		viper.GetString("telemetry.otlp_endpoint"),
		viper.GetBool("telemetry.insecure"),
	)
	if err != nil {
		slog.Warn("telemetry init failed", "err", err)
	} else {
		defer func() { _ = shutdown(context.Background()) }()
	}

	// ── K8s client (uses in-cluster config or ~/.kube/config) ────────────────
	scheme := runtime.NewScheme()
	utilruntime.Must(clientgoscheme.AddToScheme(scheme))
	utilruntime.Must(sandboxv1.AddToScheme(scheme))
	utilruntime.Must(extv1.AddToScheme(scheme))

	restCfg, err := ctrl.GetConfig()
	if err != nil {
		slog.Error("k8s config", "err", err)
		os.Exit(1)
	}
	k8sClient, err := client.New(restCfg, client.Options{Scheme: scheme})
	if err != nil {
		slog.Error("k8s client", "err", err)
		os.Exit(1)
	}

	namespace := viper.GetString("platform.namespace")
	if namespace == "" {
		namespace = "default"
	}

	// ── SandboxClient ─────────────────────────────────────────────────────────
	sandboxClient := code_controller.NewSandboxClient(k8sClient, namespace)

	// Bootstrap SandboxTemplates and WarmPools on startup.
	if err := bootstrapSandboxInfra(ctx, sandboxClient, viper.GetInt("platform.phase")); err != nil {
		slog.Error("sandbox infra bootstrap", "err", err)
		os.Exit(1)
	}

	// ── Storage ──────────────────────────────────────────────────────────────
	db, err := storage.Connect(ctx, viper.GetString("storage.postgres_dsn"))
	if err != nil {
		slog.Error("postgres connect", "err", err)
		os.Exit(1)
	}
	defer db.Close()

	// Auto-run SQL migrations
	if err := db.Migrate(ctx); err != nil {
		slog.Error("migrations failed", "err", err)
		os.Exit(1)
	}
	slog.Info("migrations ok")

	jobStore := storage.NewJobStore(db)

	// ── Redis Consumer ────────────────────────────────────────────────────────
	consumer, err := queue.NewConsumer(
		viper.GetString("queue.redis_url"),
		viper.GetString("queue.code_stream"),
		viper.GetString("queue.consumer_group"),
		"orchestrator-0",
		viper.GetInt("queue.block_ms"),
	)
	if err != nil {
		slog.Error("redis consumer init", "err", err)
		os.Exit(1)
	}
	defer func() { _ = consumer.Close() }()

	// ── Async Pipeline ────────────────────────────────────────────────────────
	pipeline := async.NewPipeline(&async.PipelineConfig{
		SandboxClient: sandboxClient,
		JobStore:      jobStore,
		MinioEndpoint: viper.GetString("storage.minio_endpoint"),
		MinioBucket:   viper.GetString("storage.minio_bucket"),
		MinioKey:      viper.GetString("storage.minio_access_key"),
		MinioSecret:   viper.GetString("storage.minio_secret_key"),
		MinioUseSSL:   viper.GetBool("storage.minio_use_ssl"),
		Namespace:     namespace,
		Phase:         viper.GetInt("platform.phase"),
	})

	runner := async.NewRunner(consumer, pipeline)

	slog.Info("orchestrator started", "namespace", namespace, "phase", viper.GetInt("platform.phase"))

	if err := runner.Start(ctx); err != nil && err != context.Canceled {
		slog.Error("runner stopped", "err", err)
	}

	slog.Info("orchestrator shutdown complete")
}

// bootstrapSandboxInfra ensures required SandboxTemplates and WarmPools exist.
func bootstrapSandboxInfra(ctx context.Context, sc *code_controller.SandboxClient, phase int) error {
	slog.Info("bootstrapping sandbox infrastructure", "phase", phase)

	runtimeClass := "runc"
	templateName := "code-headless-runc"
	if phase >= 3 {
		runtimeClass = "gvisor"
		templateName = "code-headless-gvisor"
	}
	if phase >= 4 {
		runtimeClass = "kata-fc"
		templateName = "code-headless-kata-fc"
	}

	limits := code_controller.ResourceLimits{
		CPU:              "2",
		Memory:           "2Gi",
		EphemeralStorage: "10Gi",
	}

	toolRunnerImage := os.Getenv("TOOL_RUNNER_IMAGE")
	if toolRunnerImage == "" {
		toolRunnerImage = "gcr.io/platform/tool-runner:latest"
	}

	if err := sc.EnsureTemplate(ctx, templateName, toolRunnerImage, runtimeClass, limits); err != nil {
		return err
	}

	poolName := templateName + "-pool"
	if err := sc.EnsureWarmPool(ctx, poolName, templateName, 5); err != nil {
		return err
	}

	slog.Info("sandbox infra ready", "template", templateName, "pool", poolName, "runtimeClass", runtimeClass)
	return nil
}
